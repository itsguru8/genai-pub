import torch
import ollama
import os
from openai import OpenAI
import argparse
import re
import json
from time import perf_counter

# ANSI escape codes for colors
PINK = '\033[95m'
CYAN = '\033[96m'
YELLOW = '\033[93m'
NEON_GREEN = '\033[92m'
RESET_COLOR = '\033[0m'

# Function to open a file and return its contents as a string
def open_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as infile:
        return infile.read()

# Function to get relevant context from the vault based on user input
def get_relevant_context(rewritten_input, vault_embeddings, vault_content, top_k=3):
    if vault_embeddings.nelement() == 0:  # Check if the tensor has any elements
        return []
    # Encode the rewritten input
    input_embedding = ollama.embeddings(model='mxbai-embed-large', prompt=rewritten_input)["embedding"]
    # Compute cosine similarity between the input and vault embeddings
    cos_scores = torch.cosine_similarity(torch.tensor(input_embedding).unsqueeze(0), vault_embeddings)
    # Adjust top_k if it's greater than the number of available scores
    top_k = min(top_k, len(cos_scores))
    # Sort the scores and get the top-k indices
    top_indices = torch.topk(cos_scores, k=top_k)[1].tolist()
    # Get the corresponding context from the vault
    relevant_context = [vault_content[idx].strip() for idx in top_indices]
    return relevant_context

   
def ollama_chat(user_input, system_message, vault_embeddings, vault_content, ollama_model, conversation_history):
    conversation_history.append({"role": "user", "content": user_input})
    
    relevant_context = get_relevant_context(user_input, vault_embeddings, vault_content)
    if relevant_context:
        context_str = "\n".join(relevant_context)
        #print("Context Pulled from Documents: \n\n" + CYAN + context_str + RESET_COLOR)
        print("Context is Pulled from Documents: now Analyzing .. \n\n" + CYAN + RESET_COLOR)
    else:
        print(CYAN + "No relevant context found." + RESET_COLOR)
    
    user_input_with_context = user_input
    if relevant_context:
        user_input_with_context = user_input + "\n\nRelevant Context:\n" + context_str
    
    conversation_history[-1]["content"] = user_input_with_context
    
    messages = [
        {"role": "system", "content": system_message},
        *conversation_history
    ]

    #measure
    t0 = perf_counter()
    
    response = client.chat.completions.create(
        model=ollama_model,
        messages=messages,
        max_tokens=2000,
    )
    t1 = perf_counter()
    time_taken = t1 - t0
    print("time taken(secs) = ",time_taken)
    
    conversation_history.append({"role": "assistant", "content": response.choices[0].message.content})
    
    return response.choices[0].message.content


# Function to upload a process file and append to vault.txt
def upload_processfile():
    p_file_path = "development-process.json"
    if p_file_path:
        with open(p_file_path, 'r', encoding="utf-8") as p_json_file:
            p_data = json.load(p_json_file)
            
            # Flatten the JSON data into a single string
            text = json.dumps(p_data, ensure_ascii=False)
            
            # Normalize whitespace and clean up text
            text = re.sub(r'\s+', ' ', text).strip()
            
            # Split text into chunks by sentences, respecting a maximum chunk size
            sentences = re.split(r'(?<=[.!?]) +', text)  # split on spaces following sentence-ending punctuation
            chunks = []
            current_chunk = ""
            for sentence in sentences:
                # Check if the current sentence plus the current chunk exceeds the limit
                if len(current_chunk) + len(sentence) + 1 < 1000:  # +1 for the space
                    current_chunk += (sentence + " ").strip()
                else:
                    # When the chunk exceeds 1000 characters, store it and start a new one
                    chunks.append(current_chunk)
                    current_chunk = sentence + " "
            if current_chunk:  # Don't forget the last chunk!
                chunks.append(current_chunk)
            with open("vault.txt", "a", encoding="utf-8") as vault_file:
                for chunk in chunks:
                    # Write each chunk to its own line
                    vault_file.write(chunk.strip() + "\n")  # Two newlines to separate chunks


# Function to upload a JSON file and append to vault.txt
def upload_jsonfile():
    file_path = "input_for_localAI.json"
    if file_path:
        with open(file_path, 'r', encoding="utf-8") as json_file:
            data = json.load(json_file)
            
            # Flatten the JSON data into a single string
            text = json.dumps(data, ensure_ascii=False)
            
            # Normalize whitespace and clean up text
            text = re.sub(r'\s+', ' ', text).strip()
            
            # Split text into chunks by sentences, respecting a maximum chunk size
            sentences = re.split(r'(?<=[.!?]) +', text)  # split on spaces following sentence-ending punctuation
            chunks = []
            current_chunk = ""
            for sentence in sentences:
                # Check if the current sentence plus the current chunk exceeds the limit
                if len(current_chunk) + len(sentence) + 1 < 1000:  # +1 for the space
                    current_chunk += (sentence + " ").strip()
                else:
                    # When the chunk exceeds 1000 characters, store it and start a new one
                    chunks.append(current_chunk)
                    current_chunk = sentence + " "
            if current_chunk:  # Don't forget the last chunk!
                chunks.append(current_chunk)
            with open("vault.txt", "a", encoding="utf-8") as vault_file:
                for chunk in chunks:
                    # Write each chunk to its own line
                    vault_file.write(chunk.strip() + "\n")  # Two newlines to separate chunks
            print(f"JSON file content appended to vault.txt with each chunk on a separate line.")



## MAIN ##
# Parse command-line arguments
print(NEON_GREEN + "Parsing command-line arguments..." + RESET_COLOR)
parser = argparse.ArgumentParser(description="Ollama Chat")
parser.add_argument("--model", default="llama3.1", help="Ollama model to use (default: llama3)")
args = parser.parse_args()

# Configuration for the Ollama API client
print(NEON_GREEN + "Initializing Ollama API client..." + RESET_COLOR)
client = OpenAI(
    base_url='http://localhost:11434/v1',
    api_key='llama3'
)

#read process
upload_processfile()

#read json
upload_jsonfile()

# Load the vault content
print(NEON_GREEN + "Loading vault content..." + RESET_COLOR)
vault_content = []
if os.path.exists("vault.txt"):
    with open("vault.txt", "r", encoding='utf-8') as vault_file:
        vault_content = vault_file.readlines()

# Generate embeddings for the vault content using Ollama
print(NEON_GREEN + "Generating embeddings for the vault content..." + RESET_COLOR)
vault_embeddings = []
for content in vault_content:
    response = ollama.embeddings(model='mxbai-embed-large', prompt=content)
    vault_embeddings.append(response["embedding"])

# Convert to tensor and print embeddings
print("Converting embeddings to tensor...")
vault_embeddings_tensor = torch.tensor(vault_embeddings) 
print("Embeddings for each line in the vault:")
print(vault_embeddings_tensor)


# Conversation loop
print("Starting conversation loop...")
conversation_history = []
system_message_default = "You are a helpful assistant that is an expert at extracting the most useful information from a given text"
system_message = "You are a helpful assistant that is an expert at extracting the most useful information from a given text.  General Instructions: You are provided with 2 JSON objects - [1] JSON Object 'development-process' provides info on software development process followed by a software company. It contains a) json array 'phases' which mentions various phases within a software development process and phases are numbered in the order of sequence that they are executed in time b) json object 'test_types_in_phase' which mentions various types of testing perfomed in a given phase c) json object 'reason_for_slippage_by_phase' which mentions various possible reasons behind something that goes wrong in a given phase. [2] JSON Object 'Issues' which contains details of different issues reported in the past on the developed software. Each issue is uniquely representated by a single JSON object containing a unique Issue-Id along with other details related to that particular Issue-Id. Refer to the above general instructions to answer the user questions . If you dont know the answer, please say so. Be clear and concise."

while True:

    user_input = input(YELLOW + "Ask a question OR Enter 1. for Issueid (or type 'quit' to exit): " + RESET_COLOR)
    if user_input.lower() == 'quit':
        break

    # Issue
    if user_input.lower() == '1':
        print("Retrieving issues for which info is available .. \n\n" + CYAN + RESET_COLOR)
        response = ollama_chat("list the issue ids you see in JSON Object Issues ", system_message, vault_embeddings_tensor, vault_content, args.model, conversation_history)        
        print(NEON_GREEN + "Response: \n\n" + response + RESET_COLOR)

        user_input = input(YELLOW + "Enter the Issueid among above to analyze: " + RESET_COLOR)
        if user_input.lower() == 'quit':
            break
        #bgprompt = "Analyze Issueid-" + user_input + "and suggest a suitable issue category among the list" + ",".join(issueCategoryList)
        rfsprompt = "Analyze the issue as below  [1]Fetch info particular to Issue-Id " + user_input + ". If not found, please say so and stop the analysis. [2] If found, derive the existing values for the following fields [a] 'Test Phase(found)'  ( lets call it 'TP') [b] 'should have been found in (phase)' ( lets call it 'SHBF(P)') [c] 'should have been found in (type)' ( lets call it 'SHBF(T)')  [d] reason for slippage ( lets call it 'RFS'). [3] Now comes the validation part to see if existing values of Issue-Id that are read from JSON Object Issues are consistent. Indicate inconsistency in the summary if any of the fields are inconsistent.  For this Issue-Id, [3.1] first, derive sequence values for fields SHBF(P) and TP and print them. If sequence value of SHBF(P) is less than or equal to sequence value of TP, then proceed to Step[3.2]. Else [a]. flag SHBF(P) as inconsistent and suggest a suitable value (lets call it 'SHBF(P)-new'). [b] Perform all subsequent steps using SHBF(P)-new in place of SHBF(P).  [3.2] If value of SHBF(T) field is part of test types listed for that SHBF(P), then proceed to Step[3.3]. Else flag the existing value as inconsistent and suggest suitable value among test types for that SHBF(P). [3.3] If value of RFS is part of reason for slippage listed for that SHBF(P), then proceed to next step. Else flag the existing value as inconsistent and suggest suitable value among reason for slippage values for that SHBF(P)"         
        
        response = ollama_chat(rfsprompt, system_message_default, vault_embeddings_tensor, vault_content, args.model, conversation_history)
        print(NEON_GREEN + "Response: \n\n" + response + RESET_COLOR)
    else:    
        response = ollama_chat(user_input, system_message, vault_embeddings_tensor, vault_content, args.model, conversation_history)
        print(NEON_GREEN + "Response: \n\n" + response + RESET_COLOR)
